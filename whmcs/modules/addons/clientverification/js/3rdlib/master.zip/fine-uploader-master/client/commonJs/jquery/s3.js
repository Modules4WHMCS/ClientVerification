"use strict";

module.exports = require("../../s3.jquery.fine-uploader/s3.jquery.fine-uploader");
