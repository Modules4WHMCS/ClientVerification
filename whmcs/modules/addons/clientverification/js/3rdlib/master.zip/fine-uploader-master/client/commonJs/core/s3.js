"use strict";

module.exports = require("../../s3.fine-uploader/s3.fine-uploader.core");
