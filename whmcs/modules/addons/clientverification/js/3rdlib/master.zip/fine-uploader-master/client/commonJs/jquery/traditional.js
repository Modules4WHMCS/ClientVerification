"use strict";

module.exports = require("../../jquery.fine-uploader/jquery.fine-uploader");
